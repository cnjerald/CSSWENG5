document.addEventListener('DOMContentLoaded', () => {
    const buttons = document.querySelectorAll('.item-btn');
    const tableWrapper = document.querySelector('.database-wrapper');

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const size = button.getAttribute('data-size');
            tableWrapper.classList.remove('small', 'medium', 'large');
            tableWrapper.classList.add(size);
        });
    });
});