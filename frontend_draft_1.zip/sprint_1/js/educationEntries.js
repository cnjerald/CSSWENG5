let entryCount = 1;

function addEntry() {
    const container = document.getElementById('entries');
    const entryDiv = document.createElement('div');
    entryDiv.classList.add('entry');
    entryDiv.innerHTML = `
        <label for="education-year">Education Year:</label><br>
        <select id="education-year${entryCount}" name="education-year[]" required>
            <option value="" disabled selected>Select your education year</option>
            <option value="1st">1st Year</option>
            <option value="2nd">2nd Year</option>
            <option value="3rd">3rd Year</option>
            <option value="4th">4th Year</option>
            <option value="5th">5th Year</option>
            <option value="graduate">Graduate</option>
            <option value="postgraduate">Postgraduate</option>
        </select><br>
        <label for="course${entryCount}">Course:</label><br>
        <input type="text" id="course${entryCount}" name="course[]" required placeholder="Enter your course"><br>
        <label for="school${entryCount}">School Attended:</label><br>
        <input type="text" id="school${entryCount}" name="school[]" required placeholder="Enter the school attended"><br>
        <button type="button" onclick="removeEntry(this)">Remove</button>
        <hr>
    `;
    container.appendChild(entryDiv);
    entryCount++;
}

function removeEntry(button) {
    const entryDiv = button.parentElement;
    entryDiv.remove();
}
