let entryCount = 1;

function addEntry() {
    const container = document.getElementById('entries');
    const entryDiv = document.createElement('div');
    entryDiv.classList.add('entry' + entryCount);
    entryDiv.innerHTML = `
        <p> Medication Name: </p>
        <input type="text" id="medication${entryCount}" name="medication${entryCount}" required><br>   
        <label for="startingDate${entryCount}"> Starting Date: </label>
        <input type="date" id="startingDate${entryCount}" name="startingDate${entryCount}" required><br>
        <button type="button" onclick="removeEntry(this)">Remove</button>
        <hr>

    `;
    container.appendChild(entryDiv);
    entryCount++;
}

function removeEntry(button) {
    const entryDiv = button.parentElement;
    entryDiv.remove();
}

