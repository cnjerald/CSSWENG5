let entryCount1 = 1;

function addEntry1() {
    const container = document.getElementById('mcid');
    const entryDiv = document.createElement('div');
    entryDiv.classList.add('mc' + entryCount1);
    entryDiv.innerHTML = `
        <input type="text" id="medicalCondition${entryCount1}" name="medicalCondition${entryCount1}" required><br>   
        <button type="button" onclick="removeEntry(this)">Remove</button>
        <hr>
    `;
    container.appendChild(entryDiv);
    entryCount++;
}

function removeEntry(button) {
    const entryDiv = button.parentElement;
    entryDiv.remove();
}

